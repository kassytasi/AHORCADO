<template>
  <router-view />
</template>

<script setup>
</script>

<style>
/* estilos globales opcionales */
</style>


